from flask import Flask, request, render_template, jsonify
import cv2
import numpy as np
import tensorflow as tf

app = Flask(__name__)
fungicide_recommendations = {
    'Gummosis': ['Mancozeb', 'Thiophanate', 'Copper-based Fungicides', 'Tebuconazole', 'Propiconazole'],
    'Other Disease': ['None']  # You can add fungicides for other diseases if needed
}

def preprocess_image(image):
    img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (256, 256))
    img = np.expand_dims(img, axis=0)
    img = img / 255.0
    return img

@app.route("/", methods=["GET", "POST"])
def upload_predict():
    recommendations = []  # Initialize recommendations here
    result = ''
    if request.method == "POST":
        image_file = request.files["image"]
        
        if image_file:
            image = cv2.imdecode(np.fromstring(image_file.read(), np.uint8), cv2.IMREAD_UNCHANGED)
            if image is None:
                return jsonify({'prediction': 'Image not loaded correctly.'})

            img = preprocess_image(image)
            prediction = model.predict(img)
            result = 'Other Disease' if prediction > 0.5 else 'Gummosis'

            recommendations = fungicide_recommendations.get(result, [])
    
    return render_template("home.html", prediction=result, recommendations=recommendations)

@app.route("/predict", methods=["POST"])
def predict():
    image_file = request.files["image"]
    
    if image_file:
        image = cv2.imdecode(np.fromstring(image_file.read(), np.uint8), cv2.IMREAD_UNCHANGED)
        if image is None:
            return jsonify({'prediction': 'Image not loaded correctly.'})

        img = preprocess_image(image)
        prediction = model.predict(img)
        result = 'Other Disease' if prediction > 0.5 else 'Gummosis'
        
        recommendations = fungicide_recommendations.get(result, [])
        
        return jsonify({'prediction': result, 'recommendations': recommendations})
    
    return jsonify({'prediction': 'No image uploaded.'})

if __name__ == '__main__':
    model_path = "C:/Users/Karthik/Documents/Sugarcane_Gummosis_Application_Upload/model/Gummosis.h5"
    model = tf.keras.models.load_model(model_path, compile=False)
    
    app.run(port=2107, debug=True)
